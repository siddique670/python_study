from tkinter import filedialog, messagebox
import PIL.Image, PIL.ImageTk
import pygame.mixer as mixer
from tkinter import *
import os


class MusicPlayer:
    def __init__(self):
        mixer.init()
        self.screen = Tk()

        self.screenWidth = self.screen.winfo_screenwidth()
        self.screenHeight = self.screen.winfo_screenheight()

        self.screen.geometry("1080x720")
        self.screen.title("Music Player")
        self.screen.resizable(False, False)
        self.screen.attributes('-alpha', 0.9)
        self.screen.iconbitmap("icon.ico")
        self.screen.protocol("WM_DELETE_WINDOW", self.closeScreen)

        self.backgroundImage = PIL.Image.open(r"images/background.jpg")
        self.backgroundImage = self.backgroundImage.resize((1080, 720))
        self.backgroundImage = PIL.ImageTk.PhotoImage(self.backgroundImage)

        self.songImage = PIL.Image.open(r"images/song.jpg")
        self.songImage = self.songImage.resize((400, 150))
        self.songImage = PIL.ImageTk.PhotoImage(self.songImage)

        self.backgroundLabel = Label(self.screen, image=self.backgroundImage)
        self.backgroundLabel.pack()

        self.selectedFolder = f"{filedialog.askdirectory(title='Select your songs folder')}"
        self.songsList = os.listdir(self.selectedFolder)
        self.currentSong = self.songsList[0]

        self.titleLabel = Label(self.backgroundLabel, text="MUSIC PLAYER", font=("Olive Village", 30, "bold"), bg="#fac304")
        self.titleLabel.place(x=0, y=0, relwidth=1)

        self.setupPlayer()

        self.screen.update()
        self.screen.mainloop()

    def setupPlayer(self):
        self.currentSongTitle = self.currentSong.split(".")[0].title()

        self.playerFrame = Frame(self.backgroundLabel, width=400, height=570, bg="#9396a7", bd=2, relief="groove")
        self.playerFrame.place(x=340, y=90)

        self.songImageLabel = Label(self.playerFrame, image=self.songImage)
        self.songImageLabel.place(x=0, y=0)

        self.songTitleLabel = Label(self.playerFrame, text=self.currentSongTitle, font=("fira code", 18, "bold"), fg="white", bg="#9396a7")
        self.songTitleLabel.place(x=0, y=170, relwidth=1)

        self.playButton = Button(self.playerFrame, text="Play", width=21, font=("fira code", 16, "bold"), bg="#fac304", command=self.playSong)
        self.playButton.place(x=50, y=220)

        self.pauseButton = Button(self.playerFrame, text="Pause", width=21, font=("fira code", 16, "bold"), bg="#fac304", command=self.pauseSong)
        self.pauseButton.place(x=50, y=290)

        self.resumeButton = Button(self.playerFrame, text="Resume", width=21, font=("fira code", 16, "bold"), bg="#fac304", command=self.resumeSong)
        self.resumeButton.place(x=50, y=360)

        self.stopButton = Button(self.playerFrame, text="Stop", width=21, font=("fira code", 16, "bold"), bg="#fac304", command=self.stopSong)
        self.stopButton.place(x=50, y=430)

        self.nextButton = Button(self.playerFrame, text="Next", width=21, font=("fira code", 16, "bold"), bg="#fac304", command=self.nextSong)
        self.nextButton.place(x=50, y=500)

    def playSong(self):
        mixer.music.load(f"{self.selectedFolder}/{self.currentSong}")
        mixer.music.play()

    @staticmethod
    def pauseSong():
        mixer.music.pause()

    @staticmethod
    def resumeSong():
        mixer.music.unpause()

    @staticmethod
    def stopSong():
        mixer.music.stop()

    def nextSong(self):
        self.nextSongIndex = self.songsList.index(self.currentSong)

        if self.nextSongIndex != len(self.songsList) - 1:
            self.nextSongIndex += 1
        else:
            self.nextSongIndex = 0

        self.currentSong = self.songsList[self.nextSongIndex]
        self.currentSongTitle = self.currentSong.split(".")[0].title()
        self.songTitleLabel.config(text=self.currentSongTitle)

        self.stopSong()

    def closeScreen(self):
        if messagebox.askyesnocancel("Close", "Do you want to close?"):
            self.screen.destroy()


if __name__ == "__main__":
    player = MusicPlayer()
